Cool assignment and thanks for the help! :)

So for this assignment i did the basics plus some extra features:
- every time there is a collision, there is a sound
- every time there is a collision, there is a particle system playing for 1 second
- there is a frog imported, that has an animation
- the sphere has an animation moving from left to right
- lightning is added
- a structure (castle) out of primitives is made
